package com.example.myprak

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider

class Redact : AppCompatActivity() {
    private lateinit var editTextLocation: EditText
    private lateinit var saveButton: Button
    private lateinit var userViewModel: UserViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_redact)

        editTextLocation = findViewById(R.id.editTextLocation)
        saveButton = findViewById(R.id.saveButton)

        userViewModel = ViewModelProvider(this).get(UserViewModel::class.java)

        val selectedUserId = intent.getIntExtra("user_id", -1)

        if (selectedUserId != -1) {
            val selectedUser = userViewModel.getUserById(selectedUserId)
            selectedUser?.let {
                editTextLocation.setText(it.location)
            }
        }

        saveButton.setOnClickListener {
            val newLocation = editTextLocation.text.toString()


            val updatedUser = userViewModel.getUserById(selectedUserId)
            updatedUser?.let {
                updatedUser.location = newLocation
                userViewModel.updateUser(updatedUser)
            }

            finish()
        }
    }
}

