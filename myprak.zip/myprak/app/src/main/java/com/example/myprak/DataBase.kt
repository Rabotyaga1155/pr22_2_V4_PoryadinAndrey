package com.example.myprak


import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DataBase : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var userViewModel: UserViewModel
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_base)

        listView = findViewById(R.id.listView)
        userViewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)

        listView.adapter = adapter

        userViewModel.allUsers.observe(this, { users ->
            val facts = users.map { it.location }
            adapter.clear()
            adapter.addAll(facts)
        })

        val deleteButton = findViewById<Button>(R.id.deleteButton)
        deleteButton.setOnClickListener {
            val selectedPosition = listView.checkedItemPosition
            if (selectedPosition != ListView.INVALID_POSITION) {
                val selectedUser = userViewModel.allUsers.value?.get(selectedPosition)
                selectedUser?.let {
                    userViewModel.deleteUser(it)
                }
            }
        }
        val editButton = findViewById<Button>(R.id.editButton)
        editButton.setOnClickListener {
            val selectedPosition = listView.checkedItemPosition
            if (selectedPosition != ListView.INVALID_POSITION) {
                val selectedUser = userViewModel.allUsers.value?.get(selectedPosition)
                selectedUser?.let {
                    val intent = Intent(this, Redact::class.java)
                    intent.putExtra("user_id", selectedUser.userId)
                    startActivity(intent)
                }
            }
        }
        val addButton = findViewById<Button>(R.id.addButton)
        addButton.setOnClickListener {
            val intent = Intent(this,newfact::class.java)
            startActivity(intent)
        }
    }
}
