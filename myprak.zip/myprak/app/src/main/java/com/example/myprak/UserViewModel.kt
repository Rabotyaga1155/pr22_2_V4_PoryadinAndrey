package com.example.myprak

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData

class UserViewModel(application: Application) : AndroidViewModel(application) {
    private val userRepository = UserRepository(application)
    val allUsers: LiveData<List<Users>> = userRepository.getAllUsersLiveData()

    fun deleteUser(user: Users) {
        userRepository.deleteUser(user)
    }
    fun updateUser(user: Users) {
        userRepository.updateUser(user)
    }
    fun getUserById(userId: Int): Users? {
        return userRepository.getUserById(userId)
    }
}