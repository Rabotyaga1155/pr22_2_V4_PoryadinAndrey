package com.example.myprak

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface UserDao {

    @Insert
    fun insertUser(users: Users)

    @Query("SELECT * FROM user")
    fun getAllUsersLiveData(): LiveData<List<Users>>

    @Update
    fun updateUser(users: Users)

    @Delete
    fun deleteUser(users: Users)

    @Query("SELECT * FROM user WHERE userId = :userId")
    fun getUserById(userId: Int): Users?

}