package com.example.myprak

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class newfact : AppCompatActivity() {
    private lateinit var numberEditText: EditText
    private lateinit var factEditText: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_newfact)


        factEditText = findViewById(R.id.factEditText)


    }

    fun saveData(view: View) {
        val number = " "
        val fact = factEditText.text.toString().trim()

        if (number.isNotEmpty() && fact.isNotEmpty()) {
            val user = Users(userName = number, location = fact, email = "")
            val userRepository = UserRepository(this)
            userRepository.insertUser(user)
            finish()
        } else {
            Toast.makeText(this, "Заполните оба поля", Toast.LENGTH_SHORT).show()
        }}
}




