package com.example.myprak

import android.content.Context
import android.os.AsyncTask
import androidx.lifecycle.LiveData

class UserRepository(context: Context) {

    var db: UserDao = AppDatabase.getInstance(context)?.userDao()!!

    fun getAllUsersLiveData(): LiveData<List<Users>> {
        return db.getAllUsersLiveData()
    }
    fun getUserById(userId: Int): Users? {
        return db.getUserById(userId)
    }

    fun insertUser(users: Users) {
        insertAsyncTask(db).execute(users)
    }

    fun updateUser(users: Users) {
        db.updateUser(users)
    }

    fun deleteUser(users: Users) {
        db.deleteUser(users)
    }

    private class insertAsyncTask internal constructor(private val usersDao: UserDao) :
        AsyncTask<Users, Void, Void>() {

        override fun doInBackground(vararg params: Users): Void? {
            usersDao.insertUser(params[0])
            return null
        }
    }
}