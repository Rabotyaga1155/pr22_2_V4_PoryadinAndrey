package com.example.myprak
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext


class Second_Screen : AppCompatActivity() {
    private lateinit var numberEditText: EditText
    private lateinit var fetchFactButton: Button
    private lateinit var numbersApiTextView: TextView
    private lateinit var secondScreenViewModel: SecondScreenViewModel


    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen)

        secondScreenViewModel = ViewModelProvider(this).get(SecondScreenViewModel::class.java)
        numberEditText = findViewById(R.id.numberEditText)
        fetchFactButton = findViewById(R.id.fetchFactButton)
        numbersApiTextView = findViewById(R.id.numbersApiTextView)

        val queue = Volley.newRequestQueue(this)
        fetchFactButton.setOnClickListener {
            try{
                val numberText = numberEditText.text.toString()

                if (numberText.isNotEmpty()) {

                    val number = numberText.toInt()
                    val apiUrl = "http://numbersapi.com/$number?json"

                    val stringRequest = StringRequest(
                        Request.Method.GET, apiUrl,
                        { response ->
                            val jsonResponse = gson.fromJson(response, Map::class.java)
                            val factText = jsonResponse["text"] as String
                            numbersApiTextView.text = factText

                            val user = Users(userName = number.toString(), location = factText, email = "")
                            secondScreenViewModel.insertUser(user)
                        },
                        { error ->

                            if (error is VolleyError) {
                                if (error.networkResponse != null && error.networkResponse.data != null) {
                                    val errorMessage = String(error.networkResponse.data)
                                    numbersApiTextView.text = "Ошибка: $errorMessage"
                                } else {
                                    numbersApiTextView.text = "Ошибка: ${error.message}"
                                }
                            }
                        }
                    )
                    queue.add(stringRequest)
                } else {
                    Toast.makeText(this, "Номер не указан", Toast.LENGTH_SHORT).show()
                }
            }catch(e: Exception){
                Toast.makeText(this, "Неверный формат", android.widget.Toast.LENGTH_SHORT).show()
            }

        }
    }
    fun db_click(view: View) {
        val intent = Intent(this,DataBase::class.java)
        startActivity(intent)
    }
}