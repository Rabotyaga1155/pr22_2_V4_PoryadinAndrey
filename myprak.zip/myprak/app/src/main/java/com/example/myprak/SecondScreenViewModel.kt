package com.example.myprak

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class SecondScreenViewModel(application: Application) : AndroidViewModel(application) {
    private val userRepository: UserRepository = UserRepository(application)

    fun insertUser(users: Users) {
        userRepository.insertUser(users)
    }
}